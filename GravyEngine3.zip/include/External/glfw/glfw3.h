#ifndef __GLFW3_H
#define __GLFW3_H

#include "../../../libs/glfw/include/GLFW/glfw3.h"

#endif