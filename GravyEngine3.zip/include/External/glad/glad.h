#ifndef __GLAD_H
#define __GLAD_H

#include "../../../libs/glad/include/glad.h"

#endif