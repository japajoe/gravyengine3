#ifndef GRAVYENGINE_PROCEDURALSKYBOXSHADER_HPP
#define GRAVYENGINE_PROCEDURALSKYBOXSHADER_HPP

#include <string>
#include "../Shader.hpp"

namespace GravyEngine
{
    class ProceduralSkyboxShader
    {
    public:
        static Shader *Create();
        static void Destroy();
    };
}

#endif