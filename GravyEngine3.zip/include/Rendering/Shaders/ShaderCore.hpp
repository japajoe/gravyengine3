#ifndef GRAVYENGINE_SHADERCORE_HPP
#define GRAVYENGINE_SHADERCORE_HPP

#include <string>

namespace GravyEngine
{
    class ShaderCore
    {
    public:
        static std::string GetSource();
    };
};

#endif