#ifndef GRAVYENGINE_DEPTHSHADER_HPP
#define GRAVYENGINE_DEPTHSHADER_HPP

#include <string>
#include "../Shader.hpp"

namespace GravyEngine
{
    class DepthShader
    {
    public:
        static Shader *Create();
        static void Destroy();
    };
}

#endif